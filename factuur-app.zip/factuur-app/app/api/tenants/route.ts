import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const tenants = await prisma.tenant.findMany({
    include: { location: true },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json(tenants);
}

export async function POST(req: Request) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const { name, email, phone, locationId, monthlyRent, serviceCosts } = await req.json();
  if (!name?.trim()) return NextResponse.json({ error: "Vul een naam voor de huurder in" }, { status: 400 });

  const tenant = await prisma.tenant.create({
    data: {
      name: name.trim(),
      email: email || "",
      phone: phone || "",
      locationId: locationId || null,
      monthlyRent: parseFloat(monthlyRent) || 0,
      serviceCosts: parseFloat(serviceCosts) || 0,
    },
  });
  return NextResponse.json(tenant, { status: 201 });
}
