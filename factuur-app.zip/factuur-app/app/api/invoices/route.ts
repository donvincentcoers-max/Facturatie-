import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";
import { monthKeyOf } from "@/lib/helpers";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const invoices = await prisma.invoice.findMany({
    include: { tenant: { include: { location: true } }, lineItems: true },
    orderBy: { date: "desc" },
  });
  return NextResponse.json(invoices);
}

export async function POST(req: Request) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const body = await req.json();
  const { tenantId, period, date, dueDate, notes, lineItems } = body;

  if (!tenantId) return NextResponse.json({ error: "Kies een huurder" }, { status: 400 });

  const validLines = (lineItems || []).filter(
    (li: any) => (parseFloat(li.amount) || 0) > 0 && li.description?.trim()
  );
  if (validLines.length === 0) {
    return NextResponse.json({ error: "Voeg minstens één kostenregel toe met omschrijving en bedrag" }, { status: 400 });
  }

  const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
  if (!tenant) return NextResponse.json({ error: "Huurder niet gevonden" }, { status: 404 });

  const settings = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  const year = new Date().getFullYear();
  const number = `${settings.invoicePrefix || "FAC"}-${year}-${String(settings.invoiceCounter).padStart(3, "0")}`;

  const invoice = await prisma.$transaction(async (tx) => {
    const created = await tx.invoice.create({
      data: {
        number,
        tenantId,
        locationId: tenant.locationId,
        period: period || "",
        date,
        dueDate,
        notes: notes || "",
        status: "open",
        monthKey: monthKeyOf(date),
        lineItems: {
          create: validLines.map((li: any) => ({
            description: li.description.trim(),
            amount: parseFloat(li.amount) || 0,
            btwPercent: parseFloat(li.btwPercent) || 0,
          })),
        },
      },
      include: { lineItems: true, tenant: { include: { location: true } } },
    });
    await tx.settings.update({ where: { id: 1 }, data: { invoiceCounter: { increment: 1 } } });
    return created;
  });

  return NextResponse.json(invoice, { status: 201 });
}
