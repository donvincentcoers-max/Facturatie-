import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";
import { buildInvoicePdf } from "@/lib/pdf";
import { sendInvoiceEmail } from "@/lib/email";
import { eur, fmtDate, invoiceTotals } from "@/lib/helpers";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const invoice = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: { tenant: { include: { location: true } }, lineItems: true },
  });
  if (!invoice) return NextResponse.json({ error: "Niet gevonden" }, { status: 404 });
  if (!invoice.tenant?.email) {
    return NextResponse.json({ error: "Deze huurder heeft geen e-mailadres" }, { status: 400 });
  }

  const settings = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  const loc = invoice.tenant.location;
  const tot = invoiceTotals(invoice.lineItems);

  const body = await req.json().catch(() => ({}));
  const subject = body.subject || `Factuur ${invoice.number} - ${settings.companyName || ""}`.trim();
  const lines = invoice.lineItems.map((li) => `- ${li.description}: \u20AC ${eur(li.amount)} (btw ${li.btwPercent}%)`).join("\n");
  const defaultMessage =
`Beste ${invoice.tenant.name},

Hierbij ontvangt u factuur ${invoice.number}${invoice.period ? " voor " + invoice.period : ""}.

${lines}

Subtotaal: \u20AC ${eur(tot.excl)}
Btw: \u20AC ${eur(tot.btw)}
Totaal te betalen: \u20AC ${eur(tot.total)}
Vervaldatum: ${fmtDate(invoice.dueDate)}

Gelieve te betalen op IBAN ${settings.iban || "-"} onder vermelding van het factuurnummer.

Met vriendelijke groet,
${settings.companyName || ""}
${settings.phone || ""} ${settings.email || ""}`;
  const messageBody = body.body || defaultMessage;

  const pdfBuffer = buildInvoicePdf(
    {
      number: invoice.number,
      date: invoice.date,
      dueDate: invoice.dueDate,
      notes: invoice.notes,
      lineItems: invoice.lineItems,
      tenant: { name: invoice.tenant.name, email: invoice.tenant.email },
      locationName: loc?.name || "",
      locationAddress: loc?.address || "",
      locationZip: loc?.zip || "",
      locationCity: loc?.city || "",
    },
    settings
  );

  try {
    await sendInvoiceEmail({
      to: invoice.tenant.email,
      subject,
      body: messageBody,
      pdfBuffer,
      pdfFilename: `Factuur-${invoice.number}.pdf`,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Versturen mislukt" }, { status: 502 });
  }

  const updated = await prisma.invoice.update({
    where: { id: invoice.id },
    data: { emailSentAt: new Date() },
  });

  return NextResponse.json({ ok: true, emailSentAt: updated.emailSentAt });
}
