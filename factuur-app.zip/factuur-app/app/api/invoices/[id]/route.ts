import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";
import { monthKeyOf } from "@/lib/helpers";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const invoice = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: { tenant: { include: { location: true } }, lineItems: true },
  });
  if (!invoice) return NextResponse.json({ error: "Niet gevonden" }, { status: 404 });
  return NextResponse.json(invoice);
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const body = await req.json();
  const { period, date, dueDate, notes, lineItems, status } = body;

  const data: any = {};
  if (period !== undefined) data.period = period;
  if (date !== undefined) { data.date = date; data.monthKey = monthKeyOf(date); }
  if (dueDate !== undefined) data.dueDate = dueDate;
  if (notes !== undefined) data.notes = notes;
  if (status !== undefined) data.status = status;

  if (lineItems) {
    const validLines = lineItems.filter((li: any) => (parseFloat(li.amount) || 0) > 0 && li.description?.trim());
    if (validLines.length === 0) {
      return NextResponse.json({ error: "Voeg minstens één kostenregel toe met omschrijving en bedrag" }, { status: 400 });
    }
    await prisma.lineItem.deleteMany({ where: { invoiceId: params.id } });
    data.lineItems = {
      create: validLines.map((li: any) => ({
        description: li.description.trim(),
        amount: parseFloat(li.amount) || 0,
        btwPercent: parseFloat(li.btwPercent) || 0,
      })),
    };
  }

  const invoice = await prisma.invoice.update({
    where: { id: params.id },
    data,
    include: { lineItems: true, tenant: { include: { location: true } } },
  });
  return NextResponse.json(invoice);
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  await prisma.invoice.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
