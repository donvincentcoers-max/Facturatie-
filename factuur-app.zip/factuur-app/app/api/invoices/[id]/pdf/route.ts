import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";
import { buildInvoicePdf } from "@/lib/pdf";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const invoice = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: { tenant: { include: { location: true } }, lineItems: true },
  });
  if (!invoice) return NextResponse.json({ error: "Niet gevonden" }, { status: 404 });

  const settings = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  const loc = invoice.tenant?.location;

  const pdfBuffer = buildInvoicePdf(
    {
      number: invoice.number,
      date: invoice.date,
      dueDate: invoice.dueDate,
      notes: invoice.notes,
      lineItems: invoice.lineItems,
      tenant: invoice.tenant ? { name: invoice.tenant.name, email: invoice.tenant.email } : null,
      locationName: loc?.name || "",
      locationAddress: loc?.address || "",
      locationZip: loc?.zip || "",
      locationCity: loc?.city || "",
    },
    settings
  );

  return new NextResponse(pdfBuffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Factuur-${invoice.number}.pdf"`,
    },
  });
}
