import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  let settings = await prisma.settings.findUnique({ where: { id: 1 } });
  if (!settings) {
    settings = await prisma.settings.create({ data: { id: 1 } });
  }
  return NextResponse.json(settings);
}

export async function PUT(req: Request) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const body = await req.json();
  const {
    companyName, address, zip, city, kvk, btwNumber, iban, ibanName,
    phone, email, btwPercent, invoicePrefix,
  } = body;

  const settings = await prisma.settings.upsert({
    where: { id: 1 },
    update: {
      companyName, address, zip, city, kvk, btwNumber, iban, ibanName,
      phone, email, btwPercent: parseFloat(btwPercent) || 0, invoicePrefix: invoicePrefix || "FAC",
    },
    create: {
      id: 1, companyName, address, zip, city, kvk, btwNumber, iban, ibanName,
      phone, email, btwPercent: parseFloat(btwPercent) || 0, invoicePrefix: invoicePrefix || "FAC",
    },
  });
  return NextResponse.json(settings);
}
