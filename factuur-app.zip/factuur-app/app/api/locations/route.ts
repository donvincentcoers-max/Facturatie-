import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const locations = await prisma.location.findMany({
    include: { _count: { select: { tenants: true } } },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json(locations);
}

export async function POST(req: Request) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const { name, address, zip, city } = await req.json();
  if (!name?.trim()) return NextResponse.json({ error: "Vul een naam voor het pand in" }, { status: 400 });

  const location = await prisma.location.create({
    data: { name: name.trim(), address: address || "", zip: zip || "", city: city || "" },
  });
  return NextResponse.json(location, { status: 201 });
}
