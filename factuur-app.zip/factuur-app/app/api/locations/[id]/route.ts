import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/requireUser";

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  const { name, address, zip, city } = await req.json();
  if (!name?.trim()) return NextResponse.json({ error: "Vul een naam voor het pand in" }, { status: 400 });

  const location = await prisma.location.update({
    where: { id: params.id },
    data: { name: name.trim(), address: address || "", zip: zip || "", city: city || "" },
  });
  return NextResponse.json(location);
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

  await prisma.location.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
