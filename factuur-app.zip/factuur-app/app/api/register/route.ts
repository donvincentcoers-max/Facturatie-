import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

// New teamleden kunnen alleen een account aanmaken met de teamcode uit
// de omgevingsvariabele TEAM_SIGNUP_CODE. Zo blijft de app privé, ook al
// staat hij op internet.
export async function POST(req: Request) {
  const { name, email, password, teamCode } = await req.json();

  if (!name || !email || !password || !teamCode) {
    return NextResponse.json({ error: "Alle velden zijn verplicht." }, { status: 400 });
  }
  if (password.length < 8) {
    return NextResponse.json({ error: "Wachtwoord moet minstens 8 tekens zijn." }, { status: 400 });
  }
  const expected = process.env.TEAM_SIGNUP_CODE;
  if (!expected || teamCode !== expected) {
    return NextResponse.json({ error: "Ongeldige teamcode." }, { status: 403 });
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (existing) {
    return NextResponse.json({ error: "Er bestaat al een account met dit e-mailadres." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.create({
    data: { name, email: email.toLowerCase().trim(), passwordHash },
  });

  return NextResponse.json({ ok: true });
}
