"use client";
import { useEffect, useState } from "react";
import { ICONS } from "@/components/icons";
import { useToast } from "@/components/useToast";
import { eur } from "@/lib/helpers";

type Tenant = {
  id: string; name: string; email: string; phone: string; locationId: string | null;
  monthlyRent: number; serviceCosts: number; location?: { id: string; name: string } | null;
};
type Location = { id: string; name: string };

export default function TenantsPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Tenant | "new" | null>(null);
  const { showToast, ToastEl } = useToast();

  useEffect(() => { load(); }, []);
  async function load() {
    setLoading(true);
    const [t, l] = await Promise.all([fetch("/api/tenants").then((r) => r.json()), fetch("/api/locations").then((r) => r.json())]);
    setTenants(t); setLocations(l); setLoading(false);
  }

  async function handleDelete(t: Tenant) {
    if (!confirm("Weet je zeker dat je deze huurder wilt verwijderen? Facturen van deze huurder blijven bewaard.")) return;
    const res = await fetch(`/api/tenants/${t.id}`, { method: "DELETE" });
    if (res.ok) { showToast("Huurder verwijderd"); load(); } else showToast("Verwijderen mislukt", true);
  }

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Huurders</h1>
          <p className="page-sub">Beheer huurders en koppel ze aan een locatie</p>
        </div>
        <button className="btn accent" onClick={() => setModal("new")}>{ICONS.plus} Nieuwe huurder</button>
      </div>

      {loading ? (
        <p style={{ color: "var(--ink-soft)" }}>Laden…</p>
      ) : tenants.length === 0 ? (
        <div className="panel">
          <div className="empty">
            <div className="empty-title">Nog geen huurders toegevoegd</div>
            <p>Voeg een huurder toe en koppel deze aan een locatie.</p>
            <button className="btn accent" onClick={() => setModal("new")}>{ICONS.plus} Nieuwe huurder</button>
          </div>
        </div>
      ) : (
        <div className="panel">
          <table>
            <thead><tr><th>Naam</th><th>E-mail</th><th>Locatie</th><th>Huur</th><th>Servicekosten</th><th></th></tr></thead>
            <tbody>
              {tenants.map((t) => (
                <tr className="rowhover" key={t.id}>
                  <td className="cell-strong">{t.name}</td>
                  <td className="cell-muted">{t.email || "—"}</td>
                  <td className="cell-muted">{t.location?.name || "—"}</td>
                  <td className="mono">€ {eur(t.monthlyRent)}</td>
                  <td className="mono cell-muted">€ {eur(t.serviceCosts)}</td>
                  <td className="cell-actions">
                    <button className="btn secondary small" onClick={() => setModal(t)}>Bewerken</button>
                    <button className="btn danger small" onClick={() => handleDelete(t)}>Verwijderen</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modal && (
        <TenantModal
          data={modal === "new" ? null : modal}
          locations={locations}
          onClose={() => setModal(null)}
          onSaved={() => { setModal(null); load(); showToast("Huurder opgeslagen"); }}
          onError={(m) => showToast(m, true)}
        />
      )}
      {ToastEl}
    </>
  );
}

function TenantModal({ data, locations, onClose, onSaved, onError }: {
  data: Tenant | null; locations: Location[]; onClose: () => void; onSaved: () => void; onError: (m: string) => void;
}) {
  const [form, setForm] = useState({
    name: data?.name || "", email: data?.email || "", phone: data?.phone || "",
    locationId: data?.locationId || "", monthlyRent: data?.monthlyRent ?? "", serviceCosts: data?.serviceCosts ?? "",
  });
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!form.name.trim()) { onError("Vul een naam voor de huurder in"); return; }
    setSaving(true);
    const url = data ? `/api/tenants/${data.id}` : "/api/tenants";
    const method = data ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setSaving(false);
    if (res.ok) onSaved(); else { const d = await res.json(); onError(d.error || "Opslaan mislukt"); }
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-head"><h3>{data ? "Huurder bewerken" : "Nieuwe huurder"}</h3><button className="modal-close" onClick={onClose}>&times;</button></div>
        <div className="modal-body">
          <div className="field"><label>Naam huurder</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Voor- en achternaam of bedrijfsnaam" /></div>
          <div className="field-row">
            <div className="field"><label>E-mailadres</label><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="huurder@voorbeeld.nl" /></div>
            <div className="field"><label>Telefoon</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="06-12345678" /></div>
          </div>
          <div className="field">
            <label>Locatie</label>
            <select value={form.locationId} onChange={(e) => setForm({ ...form, locationId: e.target.value })}>
              <option value="">— Kies een locatie —</option>
              {locations.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
            {locations.length === 0 && <span className="hint">Voeg eerst een locatie toe.</span>}
          </div>
          <div className="field-row">
            <div className="field"><label>Standaard huur excl. btw</label><input type="number" step="0.01" value={form.monthlyRent} onChange={(e) => setForm({ ...form, monthlyRent: e.target.value as any })} placeholder="0.00" /></div>
            <div className="field"><label>Standaard servicekosten excl. btw</label><input type="number" step="0.01" value={form.serviceCosts} onChange={(e) => setForm({ ...form, serviceCosts: e.target.value as any })} placeholder="0.00" /></div>
          </div>
          <div className="hint">Deze bedragen worden automatisch voorgesteld zodra je een factuur voor deze huurder maakt.</div>
        </div>
        <div className="modal-foot">
          <button className="btn secondary" onClick={onClose}>Annuleren</button>
          <button className="btn accent" disabled={saving} onClick={handleSave}>{data ? "Wijzigingen opslaan" : "Huurder toevoegen"}</button>
        </div>
      </div>
    </div>
  );
}
