"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ICONS } from "@/components/icons";
import { useToast } from "@/components/useToast";
import { eur, fmtDate, invoiceStatusResolved, invoiceTotals } from "@/lib/helpers";

export default function InvoiceDetailPage({ params }: { params: { id: string } }) {
  const [inv, setInv] = useState<any>(null);
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [emailModal, setEmailModal] = useState<{ to: string; subject: string; body: string } | null>(null);
  const { showToast, ToastEl } = useToast();
  const router = useRouter();

  useEffect(() => { load(); }, []);
  async function load() {
    setLoading(true);
    const [i, s] = await Promise.all([
      fetch(`/api/invoices/${params.id}`).then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ]);
    setInv(i); setSettings(s); setLoading(false);
  }

  async function markPaid() {
    const res = await fetch(`/api/invoices/${params.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "betaald" }) });
    if (res.ok) { showToast("Factuur gemarkeerd als betaald"); load(); } else showToast("Mislukt", true);
  }

  async function handleDelete() {
    if (!confirm("Weet je zeker dat je deze factuur wilt verwijderen?")) return;
    const res = await fetch(`/api/invoices/${params.id}`, { method: "DELETE" });
    if (res.ok) { showToast("Factuur verwijderd"); router.push("/invoices"); } else showToast("Mislukt", true);
  }

  function downloadPdf() {
    window.open(`/api/invoices/${params.id}/pdf`, "_blank");
  }

  function openEmailModal() {
    if (!inv.tenant?.email) { showToast("Deze huurder heeft geen e-mailadres — vul dit eerst aan bij de huurder", true); return; }
    const tot = invoiceTotals(inv.lineItems);
    const s = settings;
    const lines = inv.lineItems.map((li: any) => `- ${li.description}: € ${eur(li.amount)} (btw ${li.btwPercent}%)`).join("\n");
    const subject = `Factuur ${inv.number} - ${s.companyName || ""}`.trim();
    const body =
`Beste ${inv.tenant.name},

Hierbij ontvangt u factuur ${inv.number}${inv.period ? " voor " + inv.period : ""}.

${lines}

Subtotaal: € ${eur(tot.excl)}
Btw: € ${eur(tot.btw)}
Totaal te betalen: € ${eur(tot.total)}
Vervaldatum: ${fmtDate(inv.dueDate)}

Gelieve te betalen op IBAN ${s.iban || "-"} onder vermelding van het factuurnummer.

Met vriendelijke groet,
${s.companyName || ""}
${s.phone || ""} ${s.email || ""}`;
    setEmailModal({ to: inv.tenant.email, subject, body });
  }

  async function handleSendEmail() {
    if (!emailModal) return;
    const res = await fetch(`/api/invoices/${params.id}/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject: emailModal.subject, body: emailModal.body }),
    });
    if (res.ok) { showToast("Factuur verstuurd per e-mail"); setEmailModal(null); load(); }
    else { const d = await res.json(); showToast(d.error || "Versturen mislukt", true); }
  }

  if (loading || !inv || !settings) return <p style={{ color: "var(--ink-soft)" }}>Laden…</p>;

  const t = inv.tenant || { name: "Onbekende huurder", email: "" };
  const l = inv.tenant?.location || { name: "—", address: "", zip: "", city: "" };
  const s = settings;
  const tot = invoiceTotals(inv.lineItems);
  const st = invoiceStatusResolved(inv);

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Factuur {inv.number}</h1>
          <p className="page-sub">{inv.tenant?.name || "Onbekende huurder"} — {l.name}</p>
        </div>
        <button className="btn secondary" onClick={() => router.push("/invoices")}>Terug naar facturen</button>
      </div>

      <div className="panel" style={{ maxWidth: 680 }}>
        <div className="modal-body" style={{ padding: 20 }}>
          <div className="invoice-doc">
            <div className="stamp"><div className="stamp-inner"><b>FACTUUR</b><span>{st === "paid" ? "BETAALD" : "ORIGINEEL"}</span></div></div>
            <div className="inv-head">
              <div>
                <div className="display" style={{ fontSize: 20, fontWeight: 600 }}>{s.companyName || "Jouw bedrijf"}</div>
                <div className="inv-meta">
                  <div>{s.address}</div>
                  <div>{s.zip} {s.city}</div>
                  <div>KVK {s.kvk || "—"} · BTW {s.btwNumber || "—"}</div>
                </div>
              </div>
              <div className="inv-meta" style={{ textAlign: "right" }}>
                <div className="mono cell-strong" style={{ fontSize: 14 }}>{inv.number}</div>
                <div>Datum: {fmtDate(inv.date)}</div>
                <div>Vervaldatum: {fmtDate(inv.dueDate)}</div>
              </div>
            </div>
            <div className="inv-parties">
              <div><div className="inv-party-label">Factuur aan</div><div className="inv-party"><b>{t.name}</b><br />{t.email}</div></div>
              <div><div className="inv-party-label">Betreft locatie</div><div className="inv-party"><b>{l.name}</b><br />{l.address} {l.zip} {l.city}</div></div>
            </div>
            <table className="inv-table">
              <thead><tr><th>Omschrijving</th><th style={{ textAlign: "right" }}>Bedrag</th><th style={{ textAlign: "right" }}>Btw</th></tr></thead>
              <tbody>
                {inv.lineItems.map((li: any) => (
                  <tr key={li.id}><td>{li.description}</td><td className="mono" style={{ textAlign: "right" }}>€ {eur(li.amount)}</td><td className="mono cell-muted" style={{ textAlign: "right" }}>{li.btwPercent}%</td></tr>
                ))}
              </tbody>
            </table>
            {inv.notes && <div className="cell-muted" style={{ fontSize: 12, marginTop: 6 }}>{inv.notes}</div>}
            <div className="inv-totals">
              <div className="inv-totals-row"><span>Subtotaal</span><span className="mono">€ {eur(tot.excl)}</span></div>
              <div className="inv-totals-row"><span>Btw</span><span className="mono">€ {eur(tot.btw)}</span></div>
              <div className="inv-totals-row total"><span>Totaal</span><span className="mono">€ {eur(tot.total)}</span></div>
            </div>
            <div className="inv-foot">
              <div>IBAN: {s.iban || "—"} {s.ibanName ? "t.n.v. " + s.ibanName : ""}</div>
              <div>{s.email} {s.phone ? " · " + s.phone : ""}</div>
            </div>
          </div>
        </div>
        <div className="modal-foot" style={{ justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 8 }}>
            {st !== "paid" && <button className="btn small" style={{ background: "var(--success)", borderColor: "var(--success)", color: "#fff" }} onClick={markPaid}>Markeer betaald</button>}
            <button className="btn danger small" onClick={handleDelete}>Verwijderen</button>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn secondary" onClick={downloadPdf}>{ICONS.pdf} PDF downloaden</button>
            <button className="btn accent" onClick={openEmailModal}>{ICONS.mail} Factuur e-mailen</button>
          </div>
        </div>
        {inv.emailSentAt && <div className="note-box" style={{ margin: "0 24px 20px" }}>Laatst verstuurd per e-mail op {fmtDate(inv.emailSentAt)}.</div>}
      </div>

      {emailModal && (
        <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) setEmailModal(null); }}>
          <div className="modal" style={{ maxWidth: 560 }}>
            <div className="modal-head"><h3>Factuur e-mailen — {inv.number}</h3><button className="modal-close" onClick={() => setEmailModal(null)}>&times;</button></div>
            <div className="modal-body">
              <div className="note-box">De e-mail wordt écht verstuurd via je e-mailservice, met de factuur-PDF als bijlage.</div>
              <div className="field"><label>Aan</label><input value={emailModal.to} onChange={(e) => setEmailModal({ ...emailModal, to: e.target.value })} /></div>
              <div className="field"><label>Onderwerp</label><input value={emailModal.subject} onChange={(e) => setEmailModal({ ...emailModal, subject: e.target.value })} /></div>
              <div className="field"><label>Bericht</label><textarea style={{ minHeight: 220 }} value={emailModal.body} onChange={(e) => setEmailModal({ ...emailModal, body: e.target.value })} /></div>
            </div>
            <div className="modal-foot" style={{ justifyContent: "space-between" }}>
              <button className="btn secondary" onClick={downloadPdf}>{ICONS.pdf} PDF downloaden</button>
              <button className="btn accent" onClick={handleSendEmail}>{ICONS.mail} Versturen</button>
            </div>
          </div>
        </div>
      )}
      {ToastEl}
    </>
  );
}
