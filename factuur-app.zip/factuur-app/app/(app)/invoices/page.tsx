"use client";
import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { ICONS } from "@/components/icons";
import { useToast } from "@/components/useToast";
import { addDays, eur, fmtDate, invoiceStatusResolved, invoiceTotals, todayISO } from "@/lib/helpers";

const LINE_TYPES = ["Huur", "Servicekosten", "Overig"];

export default function InvoicesPage() {
  return (
    <Suspense fallback={<p style={{ color: "var(--ink-soft)" }}>Laden…</p>}>
      <InvoicesPageInner />
    </Suspense>
  );
}

function InvoicesPageInner() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [tenants, setTenants] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({ btwPercent: 21 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [presetTenant, setPresetTenant] = useState<string | null>(null);
  const { showToast, ToastEl } = useToast();
  const params = useSearchParams();
  const router = useRouter();

  useEffect(() => { load(); }, []);
  useEffect(() => {
    const newFor = params.get("newFor");
    if (newFor) { setPresetTenant(newFor); setModalOpen(true); router.replace("/invoices"); }
  }, [params]);

  async function load() {
    setLoading(true);
    const [i, t, s] = await Promise.all([
      fetch("/api/invoices").then((r) => r.json()),
      fetch("/api/tenants").then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ]);
    setInvoices(i); setTenants(t); setSettings(s); setLoading(false);
  }

  async function markPaid(id: string) {
    const res = await fetch(`/api/invoices/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "betaald" }) });
    if (res.ok) { showToast("Factuur gemarkeerd als betaald"); load(); } else showToast("Mislukt", true);
  }

  let list = invoices;
  if (statusFilter !== "all") list = list.filter((i) => invoiceStatusResolved(i) === statusFilter);
  if (search.trim()) {
    const q = search.toLowerCase();
    list = list.filter((i) => i.number.toLowerCase().includes(q) || i.tenant?.name?.toLowerCase().includes(q) || i.tenant?.location?.name?.toLowerCase().includes(q));
  }
  list = [...list].sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Facturen</h1>
          <p className="page-sub">Maak, verstuur en volg facturen op</p>
        </div>
        <button className="btn accent" onClick={() => { setPresetTenant(null); setModalOpen(true); }}>{ICONS.plus} Nieuwe factuur</button>
      </div>

      <div className="tabs-toolbar">
        <input className="search-input" placeholder="Zoek op nummer, huurder, locatie…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="filter" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">Alle statussen</option>
          <option value="open">Open</option>
          <option value="overdue">Te laat</option>
          <option value="paid">Betaald</option>
        </select>
      </div>

      {loading ? (
        <p style={{ color: "var(--ink-soft)" }}>Laden…</p>
      ) : invoices.length === 0 ? (
        <div className="panel">
          <div className="empty">
            <div className="empty-title">Nog geen facturen</div>
            <p>Stel eerst een locatie en huurder in, maak daarna je eerste factuur.</p>
            <button className="btn accent" onClick={() => setModalOpen(true)}>{ICONS.plus} Nieuwe factuur</button>
          </div>
        </div>
      ) : list.length === 0 ? (
        <div className="panel"><div className="empty"><div className="empty-title">Geen facturen gevonden</div><p>Pas je zoekopdracht of filter aan.</p></div></div>
      ) : (
        <div className="panel">
          <table>
            <thead><tr><th>Nummer</th><th>Huurder</th><th>Locatie</th><th>Periode</th><th>Vervaldatum</th><th>Bedrag</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {list.map((inv) => {
                const st = invoiceStatusResolved(inv);
                return (
                  <tr className="rowhover" key={inv.id}>
                    <td className="mono cell-strong">{inv.number}</td>
                    <td>{inv.tenant?.name || <span className="cell-muted">Verwijderde huurder</span>}</td>
                    <td className="cell-muted">{inv.tenant?.location?.name || "—"}</td>
                    <td className="cell-muted">{inv.period || "—"}</td>
                    <td className="cell-muted">{fmtDate(inv.dueDate)}</td>
                    <td className="mono">€ {eur(invoiceTotals(inv.lineItems).total)}</td>
                    <td>
                      {st === "paid" && <span className="badge paid"><span className="badge-dot"></span>Betaald</span>}
                      {st === "overdue" && <span className="badge overdue"><span className="badge-dot"></span>Te laat</span>}
                      {st === "open" && <span className="badge open"><span className="badge-dot"></span>Open</span>}
                    </td>
                    <td className="cell-actions">
                      <Link href={`/invoices/${inv.id}`} className="btn secondary small">Bekijken</Link>
                      {st !== "paid" && (
                        <button className="btn small" style={{ background: "var(--success)", borderColor: "var(--success)", color: "#fff" }} onClick={() => markPaid(inv.id)}>Markeer betaald</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <InvoiceFormModal
          tenants={tenants}
          settings={settings}
          presetTenantId={presetTenant}
          onClose={() => setModalOpen(false)}
          onSaved={() => { setModalOpen(false); load(); showToast("Factuur opgeslagen"); }}
          onError={(m) => showToast(m, true)}
        />
      )}
      {ToastEl}
    </>
  );
}

function InvoiceFormModal({ tenants, settings, presetTenantId, onClose, onSaved, onError }: {
  tenants: any[]; settings: any; presetTenantId: string | null;
  onClose: () => void; onSaved: () => void; onError: (m: string) => void;
}) {
  const date = todayISO();
  const presetTenant = presetTenantId ? tenants.find((t) => t.id === presetTenantId) : null;
  const initialLines = () => {
    if (presetTenant) {
      const lines = [];
      if (presetTenant.monthlyRent) lines.push({ description: "Huur", amount: presetTenant.monthlyRent, btwPercent: settings.btwPercent || 21 });
      if (presetTenant.serviceCosts) lines.push({ description: "Servicekosten", amount: presetTenant.serviceCosts, btwPercent: settings.btwPercent || 21 });
      if (lines.length) return lines;
    }
    return [{ description: "", amount: "", btwPercent: settings.btwPercent || 21 }];
  };

  const [tenantId, setTenantId] = useState(presetTenantId || "");
  const [period, setPeriod] = useState("");
  const [invDate, setInvDate] = useState(date);
  const [dueDate, setDueDate] = useState(addDays(date, 14));
  const [notes, setNotes] = useState("");
  const [lineItems, setLineItems] = useState<any[]>(initialLines());
  const [touched, setTouched] = useState(!!presetTenant);
  const [saving, setSaving] = useState(false);

  function handleTenantChange(id: string) {
    setTenantId(id);
    if (!touched) {
      const t = tenants.find((x) => x.id === id);
      if (t) {
        const lines = [];
        if (t.monthlyRent) lines.push({ description: `Huur${period ? " — " + period : ""}`, amount: t.monthlyRent, btwPercent: settings.btwPercent || 21 });
        if (t.serviceCosts) lines.push({ description: "Servicekosten", amount: t.serviceCosts, btwPercent: settings.btwPercent || 21 });
        if (lines.length) setLineItems(lines);
      }
    }
  }

  function updateLine(idx: number, field: string, value: any) {
    setTouched(true);
    setLineItems((prev) => prev.map((li, i) => (i === idx ? { ...li, [field]: value } : li)));
  }
  function addLine(description = "") {
    setTouched(true);
    setLineItems((prev) => [...prev, { description, amount: "", btwPercent: settings.btwPercent || 21 }]);
  }
  function removeLine(idx: number) {
    if (lineItems.length <= 1) return;
    setTouched(true);
    setLineItems((prev) => prev.filter((_, i) => i !== idx));
  }

  const totals = invoiceTotals(lineItems);

  async function handleSave() {
    if (!tenantId) { onError("Kies een huurder"); return; }
    const validLines = lineItems.filter((li) => (parseFloat(li.amount) || 0) > 0 && li.description.trim());
    if (validLines.length === 0) { onError("Voeg minstens één kostenregel toe met omschrijving en bedrag"); return; }
    setSaving(true);
    const res = await fetch("/api/invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tenantId, period, date: invDate, dueDate, notes, lineItems }),
    });
    setSaving(false);
    if (res.ok) onSaved(); else { const d = await res.json(); onError(d.error || "Opslaan mislukt"); }
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={{ maxWidth: 600 }}>
        <div className="modal-head"><h3>Nieuwe factuur</h3><button className="modal-close" onClick={onClose}>&times;</button></div>
        <div className="modal-body">
          <div className="field">
            <label>Huurder</label>
            <select value={tenantId} onChange={(e) => handleTenantChange(e.target.value)}>
              <option value="">— Kies een huurder —</option>
              {tenants.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            {tenants.length === 0 ? <span className="hint">Voeg eerst een huurder toe.</span> : <span className="hint">Bij het kiezen van een huurder worden standaardbedragen voorgesteld.</span>}
          </div>
          <div className="field-row">
            <div className="field"><label>Periode</label><input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="Bijv. Augustus 2026" /></div>
            <div className="field"><label>Factuurdatum</label><input type="date" value={invDate} onChange={(e) => setInvDate(e.target.value)} /></div>
          </div>
          <div className="field"><label>Vervaldatum</label><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></div>

          <div className="field">
            <label>Kostenregels</label>
            <div className="type-chips">
              {LINE_TYPES.map((t) => <button type="button" key={t} className="type-chip" onClick={() => addLine(t)}>+ {t}</button>)}
            </div>
            <div className="lineitems">
              <div className="lineitem-head"><span>Omschrijving</span><span>Bedrag €</span><span>Btw %</span><span></span></div>
              {lineItems.map((li, idx) => (
                <div className="lineitem-row" key={idx}>
                  <input value={li.description} onChange={(e) => updateLine(idx, "description", e.target.value)} placeholder="Omschrijving" />
                  <input type="number" step="0.01" value={li.amount} onChange={(e) => updateLine(idx, "amount", e.target.value)} placeholder="0.00" />
                  <input type="number" value={li.btwPercent} onChange={(e) => updateLine(idx, "btwPercent", e.target.value)} min={0} max={100} />
                  <button type="button" className="btn ghost" disabled={lineItems.length <= 1} onClick={() => removeLine(idx)}>{ICONS.trash}</button>
                </div>
              ))}
              <div className="lineitems-foot"><button type="button" className="btn secondary small" onClick={() => addLine()}>{ICONS.plus} Regel toevoegen</button></div>
            </div>
            <div className="lineitems-total">
              <span>Subtotaal excl. btw: <b>€ {eur(totals.excl)}</b></span>
              <span>Btw: <b>€ {eur(totals.btw)}</b></span>
              <span>Totaal: <b>€ {eur(totals.total)}</b></span>
            </div>
          </div>

          <div className="field"><label>Opmerking <span className="hint">(optioneel, komt op de factuur)</span></label><textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
        </div>
        <div className="modal-foot">
          <button className="btn secondary" onClick={onClose}>Annuleren</button>
          <button className="btn accent" disabled={saving} onClick={handleSave}>Factuur aanmaken</button>
        </div>
      </div>
    </div>
  );
}
