"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ICONS } from "@/components/icons";
import { eur, fmtDate, invoiceStatusResolved, invoiceTotals, monthKeyOf, monthLabel } from "@/lib/helpers";

export default function DashboardPage() {
  const [locations, setLocations] = useState<any[]>([]);
  const [tenants, setTenants] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [l, t, i] = await Promise.all([
      fetch("/api/locations").then((r) => r.json()),
      fetch("/api/tenants").then((r) => r.json()),
      fetch("/api/invoices").then((r) => r.json()),
    ]);
    setLocations(l); setTenants(t); setInvoices(i);
    setLoading(false);
  }

  if (loading) return <p style={{ color: "var(--ink-soft)" }}>Gegevens laden…</p>;

  const openInvoices = invoices.filter((i) => invoiceStatusResolved(i) !== "paid");
  const overdue = invoices.filter((i) => invoiceStatusResolved(i) === "overdue");
  const openTotal = openInvoices.reduce((s, i) => s + invoiceTotals(i.lineItems).total, 0);
  const overdueTotal = overdue.reduce((s, i) => s + invoiceTotals(i.lineItems).total, 0);
  const mk = monthKeyOf();
  const missing = tenants.filter((t) => !invoices.some((i) => i.tenantId === t.id && i.monthKey === mk));
  const recent = [...invoices].sort((a, b) => (b.date || "").localeCompare(a.date || "")).slice(0, 6);

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Overzicht</h1>
          <p className="page-sub">Actuele stand van zaken over al je panden en huurders</p>
        </div>
      </div>

      {missing.length > 0 && (
        <div className="reminder-banner">
          <div>
            <div className="reminder-banner-text">
              {ICONS.bell} <b>Herinnering:</b> {missing.length} huurder{missing.length > 1 ? "s hebben" : " heeft"} nog geen factuur voor {monthLabel(mk)}.
            </div>
            <div className="reminder-list">
              {missing.map((t) => (
                <span className="reminder-chip" key={t.id}>
                  {t.name}
                  <Link href={`/invoices?newFor=${t.id}`} className="btn accent small" style={{ padding: "3px 9px" }}>
                    Factuur maken
                  </Link>
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="stat-row">
        <div className="stat-card"><div className="stat-label">Panden</div><div className="stat-value">{locations.length}</div></div>
        <div className="stat-card"><div className="stat-label">Huurders</div><div className="stat-value">{tenants.length}</div></div>
        <div className="stat-card"><div className="stat-label">Openstaand bedrag</div><div className="stat-value accent-text">€ {eur(openTotal)}</div></div>
        <div className="stat-card"><div className="stat-label">Te laat ({overdue.length})</div><div className={`stat-value ${overdue.length ? "danger-text" : ""}`}>€ {eur(overdueTotal)}</div></div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h3>Recente facturen</h3>
          <Link href="/invoices" className="btn secondary small">Alle facturen</Link>
        </div>
        {recent.length === 0 ? (
          <div className="empty">
            <div className="empty-title">Nog geen facturen</div>
            <p>Maak je eerste factuur aan om hier je overzicht te zien.</p>
            <Link href="/invoices" className="btn accent">{ICONS.plus} Nieuwe factuur</Link>
          </div>
        ) : (
          <table>
            <thead><tr><th>Nummer</th><th>Huurder</th><th>Locatie</th><th>Datum</th><th>Bedrag</th><th>Status</th></tr></thead>
            <tbody>
              {recent.map((inv) => {
                const st = invoiceStatusResolved(inv);
                return (
                  <tr className="rowhover" key={inv.id}>
                    <td className="mono cell-strong"><Link href={`/invoices/${inv.id}`}>{inv.number}</Link></td>
                    <td>{inv.tenant?.name || "—"}</td>
                    <td className="cell-muted">{inv.tenant?.location?.name || "—"}</td>
                    <td className="cell-muted">{fmtDate(inv.date)}</td>
                    <td className="mono">€ {eur(invoiceTotals(inv.lineItems).total)}</td>
                    <td>
                      {st === "paid" && <span className="badge paid"><span className="badge-dot"></span>Betaald</span>}
                      {st === "overdue" && <span className="badge overdue"><span className="badge-dot"></span>Te laat</span>}
                      {st === "open" && <span className="badge open"><span className="badge-dot"></span>Open</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
