"use client";
import { useEffect, useState } from "react";
import { ICONS } from "@/components/icons";
import { useToast } from "@/components/useToast";

type Location = { id: string; name: string; address: string; zip: string; city: string; _count?: { tenants: number } };

export default function LocationsPage() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Location | "new" | null>(null);
  const { showToast, ToastEl } = useToast();

  useEffect(() => { load(); }, []);
  async function load() {
    setLoading(true);
    const l = await fetch("/api/locations").then((r) => r.json());
    setLocations(l); setLoading(false);
  }

  async function handleDelete(loc: Location) {
    if ((loc._count?.tenants || 0) > 0 && !confirm("Deze locatie heeft gekoppelde huurders. Toch verwijderen?")) return;
    const res = await fetch(`/api/locations/${loc.id}`, { method: "DELETE" });
    if (res.ok) { showToast("Locatie verwijderd"); load(); } else showToast("Verwijderen mislukt", true);
  }

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Locaties</h1>
          <p className="page-sub">Beheer de panden die je verhuurt</p>
        </div>
        <button className="btn accent" onClick={() => setModal("new")}>{ICONS.plus} Nieuwe locatie</button>
      </div>

      {loading ? (
        <p style={{ color: "var(--ink-soft)" }}>Laden…</p>
      ) : locations.length === 0 ? (
        <div className="panel">
          <div className="empty">
            <div className="empty-title">Nog geen locaties toegevoegd</div>
            <p>Voeg het eerste pand of de eerste garagebox toe die je verhuurt.</p>
            <button className="btn accent" onClick={() => setModal("new")}>{ICONS.plus} Nieuwe locatie</button>
          </div>
        </div>
      ) : (
        <div className="panel">
          <table>
            <thead><tr><th>Naam</th><th>Adres</th><th>Plaats</th><th>Huurders</th><th></th></tr></thead>
            <tbody>
              {locations.map((loc) => (
                <tr className="rowhover" key={loc.id}>
                  <td className="cell-strong">{loc.name}</td>
                  <td className="cell-muted">{loc.address}</td>
                  <td className="cell-muted">{loc.zip} {loc.city}</td>
                  <td>{loc._count?.tenants ?? 0}</td>
                  <td className="cell-actions">
                    <button className="btn secondary small" onClick={() => setModal(loc)}>Bewerken</button>
                    <button className="btn danger small" onClick={() => handleDelete(loc)}>Verwijderen</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modal && (
        <LocationModal
          data={modal === "new" ? null : modal}
          onClose={() => setModal(null)}
          onSaved={() => { setModal(null); load(); showToast("Locatie opgeslagen"); }}
          onError={(m) => showToast(m, true)}
        />
      )}
      {ToastEl}
    </>
  );
}

function LocationModal({ data, onClose, onSaved, onError }: { data: Location | null; onClose: () => void; onSaved: () => void; onError: (m: string) => void }) {
  const [form, setForm] = useState({ name: data?.name || "", address: data?.address || "", zip: data?.zip || "", city: data?.city || "" });
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!form.name.trim()) { onError("Vul een naam voor het pand in"); return; }
    setSaving(true);
    const url = data ? `/api/locations/${data.id}` : "/api/locations";
    const method = data ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setSaving(false);
    if (res.ok) onSaved(); else { const d = await res.json(); onError(d.error || "Opslaan mislukt"); }
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-head"><h3>{data ? "Locatie bewerken" : "Nieuwe locatie"}</h3><button className="modal-close" onClick={onClose}>&times;</button></div>
        <div className="modal-body">
          <div className="field"><label>Naam van het pand / de garagebox</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Bijv. Garagebox 12, Hoofdstraat" /></div>
          <div className="field"><label>Adres</label><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Straat en huisnummer" /></div>
          <div className="field-row">
            <div className="field"><label>Postcode</label><input value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} placeholder="1234 AB" /></div>
            <div className="field"><label>Plaats</label><input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="Rotterdam" /></div>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn secondary" onClick={onClose}>Annuleren</button>
          <button className="btn accent" disabled={saving} onClick={handleSave}>{data ? "Wijzigingen opslaan" : "Locatie toevoegen"}</button>
        </div>
      </div>
    </div>
  );
}
