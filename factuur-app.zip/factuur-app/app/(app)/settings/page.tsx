"use client";
import { useEffect, useState } from "react";
import { useToast } from "@/components/useToast";

const DEFAULTS = {
  companyName: "", address: "", zip: "", city: "", kvk: "", btwNumber: "", iban: "", ibanName: "",
  phone: "", email: "", btwPercent: 21, invoicePrefix: "FAC", invoiceCounter: 1,
};

export default function SettingsPage() {
  const [s, setS] = useState<any>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const { showToast, ToastEl } = useToast();

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((d) => { setS(d); setLoading(false); });
  }, []);

  function field(key: string, value: any) { setS((prev: any) => ({ ...prev, [key]: value })); }

  async function handleSave() {
    const res = await fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    if (res.ok) { const d = await res.json(); setS(d); showToast("Instellingen opgeslagen"); }
    else showToast("Opslaan mislukt", true);
  }

  const nextNumber = `${s.invoicePrefix || "FAC"}-${new Date().getFullYear()}-${String(s.invoiceCounter || 1).padStart(3, "0")}`;

  return (
    <>
      <div className="topbar">
        <div>
          <h1 className="page-title">Instellingen</h1>
          <p className="page-sub">Bedrijfs- en factuurgegevens voor op elke factuur</p>
        </div>
      </div>

      {loading ? (
        <p style={{ color: "var(--ink-soft)" }}>Laden…</p>
      ) : (
        <div className="panel">
          <div className="panel-head"><h3>Bedrijfs- en factuurgegevens</h3></div>
          <div style={{ padding: "22px 24px" }}>
            <div className="kv-grid">
              <div className="field"><label>Bedrijfsnaam</label><input value={s.companyName} onChange={(e) => field("companyName", e.target.value)} placeholder="Bijv. Van der Berg Vastgoed" /></div>
              <div className="field"><label>E-mailadres (afzender)</label><input value={s.email} onChange={(e) => field("email", e.target.value)} placeholder="info@voorbeeld.nl" /></div>
              <div className="field"><label>Adres</label><input value={s.address} onChange={(e) => field("address", e.target.value)} placeholder="Straatnaam 12" /></div>
              <div className="field"><label>Telefoon</label><input value={s.phone} onChange={(e) => field("phone", e.target.value)} placeholder="06-12345678" /></div>
              <div className="field"><label>Postcode</label><input value={s.zip} onChange={(e) => field("zip", e.target.value)} placeholder="1234 AB" /></div>
              <div className="field"><label>Plaats</label><input value={s.city} onChange={(e) => field("city", e.target.value)} placeholder="Rotterdam" /></div>
              <div className="field"><label>KVK-nummer</label><input value={s.kvk} onChange={(e) => field("kvk", e.target.value)} placeholder="12345678" /></div>
              <div className="field"><label>BTW-nummer</label><input value={s.btwNumber} onChange={(e) => field("btwNumber", e.target.value)} placeholder="NL000000000B00" /></div>
              <div className="field"><label>IBAN</label><input value={s.iban} onChange={(e) => field("iban", e.target.value)} placeholder="NL00 BANK 0000 0000 00" /></div>
              <div className="field"><label>Tenaamstelling rekening</label><input value={s.ibanName} onChange={(e) => field("ibanName", e.target.value)} placeholder="T.n.v. …" /></div>
              <div className="field"><label>Standaard BTW-percentage</label><input type="number" value={s.btwPercent} min={0} max={100} onChange={(e) => field("btwPercent", e.target.value)} /><span className="hint">Garageboxen worden standaard belast verhuurd (21%).</span></div>
              <div className="field"><label>Factuurnummer prefix</label><input value={s.invoicePrefix} onChange={(e) => field("invoicePrefix", e.target.value)} placeholder="FAC" /><span className="hint">Volgende nummer: {nextNumber}</span></div>
            </div>
            <div style={{ marginTop: 20, display: "flex", justifyContent: "flex-end" }}>
              <button className="btn accent" onClick={handleSave}>Instellingen opslaan</button>
            </div>
          </div>
        </div>
      )}
      {ToastEl}
    </>
  );
}
