"use client";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { useEffect, useState } from "react";
import { signOut, useSession } from "next-auth/react";
import { ICONS } from "@/components/icons";
import { monthKeyOf } from "@/lib/helpers";

const NAV = [
  { key: "dashboard", href: "/dashboard", label: "Overzicht", icon: "dashboard" },
  { key: "locations", href: "/locations", label: "Locaties", icon: "locations" },
  { key: "tenants", href: "/tenants", label: "Huurders", icon: "tenants" },
  { key: "invoices", href: "/invoices", label: "Facturen", icon: "invoices" },
  { key: "settings", href: "/settings", label: "Instellingen", icon: "settings" },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [companyName, setCompanyName] = useState("Vastgoedbeheer");
  const [missingCount, setMissingCount] = useState(0);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((s) => setCompanyName(s.companyName || "Vastgoedbeheer")).catch(() => {});
    Promise.all([fetch("/api/tenants").then((r) => r.json()), fetch("/api/invoices").then((r) => r.json())])
      .then(([tenants, invoices]) => {
        const mk = monthKeyOf();
        const missing = (tenants || []).filter((t: any) => !(invoices || []).some((i: any) => i.tenantId === t.id && i.monthKey === mk));
        setMissingCount(missing.length);
      })
      .catch(() => {});
  }, [pathname]);

  return (
    <div id="app">
      <div className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#D9B77A" strokeWidth="1.6">
              <path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M9.5 21v-6h5v6" />
            </svg>
            <div>
              <div className="brand-title">{companyName}</div>
              <div className="brand-sub">Facturatie</div>
            </div>
          </div>
        </div>
        <div className="nav">
          {NAV.map((item) => {
            const active = pathname?.startsWith(item.href);
            const badge = item.key === "invoices" ? missingCount : 0;
            return (
              <Link key={item.key} href={item.href} className={`nav-item ${active ? "active" : ""}`}>
                {ICONS[item.icon]}
                <span>{item.label}</span>
                {badge > 0 && <span className="nav-badge">{badge}</span>}
              </Link>
            );
          })}
        </div>
        <div className="nav-foot">
          Ingelogd als {session?.user?.name || session?.user?.email}
          <br />
          <button
            onClick={() => signOut({ callbackUrl: "/login" })}
            style={{ background: "none", border: "none", color: "#C7CDD8", textDecoration: "underline", cursor: "pointer", padding: 0, marginTop: 6, fontSize: 11 }}
          >
            Uitloggen
          </button>
          <div style={{ marginTop: 10 }}>Gedeeld team-overzicht. Alle wijzigingen zijn direct zichtbaar voor collega's.</div>
        </div>
      </div>
      <div className="main">{children}</div>
    </div>
  );
}
