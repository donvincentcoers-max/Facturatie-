"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", teamCode: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error || "Aanmaken mislukt.");
      return;
    }
    router.push("/login");
  }

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <h1 className="display">Account aanmaken</h1>
        <p className="sub">Vraag de teamcode op bij een collega die de app heeft ingesteld.</p>
        {error && <div className="auth-error">{error}</div>}
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="field">
            <label>Naam</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="field">
            <label>E-mailadres</label>
            <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="field">
            <label>Wachtwoord</label>
            <input type="password" required minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            <span className="hint">Minstens 8 tekens.</span>
          </div>
          <div className="field">
            <label>Teamcode</label>
            <input required value={form.teamCode} onChange={(e) => setForm({ ...form, teamCode: e.target.value })} />
          </div>
          <button className="btn accent" type="submit" disabled={loading} style={{ justifyContent: "center", marginTop: 4 }}>
            {loading ? "Bezig…" : "Account aanmaken"}
          </button>
        </form>
        <div className="auth-foot">
          Al een account? <Link href="/login" style={{ color: "var(--accent-deep)", fontWeight: 600 }}>Inloggen</Link>
        </div>
      </div>
    </div>
  );
}
