export { default } from "next-auth/middleware";

export const config = {
  // Alles vereist login, behalve login/register/api-auth/statische bestanden.
  matcher: [
    "/((?!login|register|api/auth|api/register|_next/static|_next/image|favicon.ico).*)",
  ],
};
