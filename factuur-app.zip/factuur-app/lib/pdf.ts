import { jsPDF } from "jspdf";
import { eur, fmtDate, invoiceTotals, LineItem } from "./helpers";

type Settings = {
  companyName: string; address: string; zip: string; city: string;
  kvk: string; btwNumber: string; iban: string; ibanName: string;
  phone: string; email: string;
};
type PdfInvoice = {
  number: string; date: string; dueDate: string; notes: string;
  lineItems: LineItem[];
  tenant: { name: string; email: string } | null;
  locationName: string; locationAddress: string; locationZip: string; locationCity: string;
};

export function buildInvoicePdf(inv: PdfInvoice, s: Settings): Buffer {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const tot = invoiceTotals(inv.lineItems);
  const t = inv.tenant || { name: "Onbekende huurder", email: "" };

  const marginL = 20;
  let y = 22;
  doc.setFont("helvetica", "bold"); doc.setFontSize(18); doc.setTextColor(22, 35, 58);
  doc.text(s.companyName || "Factuur", marginL, y);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(90, 90, 90);
  y += 7; doc.text(`${s.address || ""}`, marginL, y);
  y += 5; doc.text(`${s.zip || ""} ${s.city || ""}`, marginL, y);
  y += 5; doc.text(`KVK ${s.kvk || "-"}   BTW ${s.btwNumber || "-"}`, marginL, y);

  doc.setFontSize(12); doc.setTextColor(22, 35, 58); doc.setFont("helvetica", "bold");
  doc.text(`Factuur ${inv.number}`, 140, 22);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(90, 90, 90);
  doc.text(`Datum: ${fmtDate(inv.date)}`, 140, 29);
  doc.text(`Vervaldatum: ${fmtDate(inv.dueDate)}`, 140, 34);

  y = 52;
  doc.setDrawColor(200, 200, 200); doc.line(marginL, y, 190, y);
  y += 8;
  doc.setFont("helvetica", "bold"); doc.setFontSize(10); doc.setTextColor(22, 35, 58);
  doc.text("Factuur aan", marginL, y);
  doc.text("Betreft locatie", 110, y);
  y += 6; doc.setFont("helvetica", "normal"); doc.setFontSize(10.5);
  doc.text(t.name || "-", marginL, y);
  doc.text(inv.locationName || "-", 110, y);
  y += 5; doc.setFontSize(9.5); doc.setTextColor(90, 90, 90);
  doc.text(t.email || "", marginL, y);
  doc.text(`${inv.locationAddress || ""} ${inv.locationZip || ""} ${inv.locationCity || ""}`, 110, y);

  y += 14;
  doc.setFillColor(239, 241, 238); doc.rect(marginL, y - 5, 170, 8, "F");
  doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(22, 35, 58);
  doc.text("Omschrijving", marginL + 2, y);
  doc.text("Btw", 160, y, { align: "right" });
  doc.text("Bedrag", 185, y, { align: "right" });
  y += 9;
  doc.setFont("helvetica", "normal"); doc.setFontSize(10);
  (inv.lineItems || []).forEach((li) => {
    doc.text(String(li.description || ""), marginL + 2, y);
    doc.text(`${li.btwPercent}%`, 160, y, { align: "right" });
    doc.text(`\u20AC ${eur(parseFloat(String(li.amount)) || 0)}`, 185, y, { align: "right" });
    y += 6;
  });
  if (inv.notes) { doc.setFontSize(8.5); doc.setTextColor(120, 120, 120); doc.text(String(inv.notes), marginL + 2, y); y += 6; }

  y += 8;
  doc.setDrawColor(220, 220, 220); doc.line(120, y, 190, y);
  y += 6; doc.setFontSize(10); doc.setTextColor(60, 60, 60);
  doc.text("Subtotaal", 120, y); doc.text(`\u20AC ${eur(tot.excl)}`, 185, y, { align: "right" });
  y += 6; doc.text("Btw", 120, y); doc.text(`\u20AC ${eur(tot.btw)}`, 185, y, { align: "right" });
  y += 3; doc.setDrawColor(22, 35, 58); doc.line(120, y, 190, y);
  y += 6; doc.setFont("helvetica", "bold"); doc.setFontSize(12); doc.setTextColor(22, 35, 58);
  doc.text("Totaal", 120, y); doc.text(`\u20AC ${eur(tot.total)}`, 185, y, { align: "right" });

  y += 20;
  doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(120, 120, 120);
  doc.text(`IBAN: ${s.iban || "-"} ${s.ibanName ? "t.n.v. " + s.ibanName : ""}`, marginL, y);
  y += 5; doc.text(`${s.email || ""} ${s.phone ? " | " + s.phone : ""}`, marginL, y);
  y += 5; doc.text(`Gelieve te betalen onder vermelding van factuurnummer ${inv.number}.`, marginL, y);

  return Buffer.from(doc.output("arraybuffer"));
}
