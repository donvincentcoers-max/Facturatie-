import { Resend } from "resend";

let client: Resend | null = null;
function getClient() {
  if (!client) {
    if (!process.env.RESEND_API_KEY) throw new Error("RESEND_API_KEY ontbreekt.");
    client = new Resend(process.env.RESEND_API_KEY);
  }
  return client;
}

export async function sendInvoiceEmail(opts: {
  to: string;
  subject: string;
  body: string;
  pdfBuffer: Buffer;
  pdfFilename: string;
}) {
  const from = process.env.RESEND_FROM_EMAIL;
  if (!from) throw new Error("RESEND_FROM_EMAIL ontbreekt.");

  const resend = getClient();
  const result = await resend.emails.send({
    from,
    to: opts.to,
    subject: opts.subject,
    text: opts.body,
    attachments: [
      {
        filename: opts.pdfFilename,
        content: opts.pdfBuffer.toString("base64"),
      },
    ],
  });
  if ((result as any).error) {
    throw new Error((result as any).error.message || "Versturen mislukt");
  }
  return result;
}
