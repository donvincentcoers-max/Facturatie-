export function eur(n: number | null | undefined) {
  const v = typeof n === "number" && !isNaN(n) ? n : 0;
  return v.toLocaleString("nl-NL", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function addDays(iso: string, days: number) {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function fmtDate(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("nl-NL", { day: "2-digit", month: "short", year: "numeric" });
}

export function monthKeyOf(iso?: string) {
  return (iso || todayISO()).slice(0, 7);
}

export function monthLabel(monthKey: string) {
  const [y, m] = monthKey.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("nl-NL", { month: "long", year: "numeric" });
}

export type LineItem = { id?: string; description: string; amount: number; btwPercent: number };

export function invoiceTotals(lineItems: LineItem[]) {
  let excl = 0,
    btw = 0;
  (lineItems || []).forEach((li) => {
    const a = parseFloat(String(li.amount)) || 0;
    const p = parseFloat(String(li.btwPercent)) || 0;
    excl += a;
    btw += (a * p) / 100;
  });
  return { excl, btw, total: excl + btw };
}

export function invoiceStatusResolved(inv: { status: string; dueDate?: string | null }) {
  if (inv.status === "betaald") return "paid";
  if (inv.dueDate && inv.dueDate < todayISO()) return "overdue";
  return "open";
}
