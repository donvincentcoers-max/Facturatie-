"use client";
import { useCallback, useRef, useState } from "react";

export function useToast() {
  const [toast, setToast] = useState<{ msg: string; error?: boolean } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const showToast = useCallback((msg: string, error = false) => {
    setToast({ msg, error });
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  const ToastEl = toast ? (
    <div className={`toast ${toast.error ? "error" : ""}`}>{toast.msg}</div>
  ) : null;

  return { showToast, ToastEl };
}
