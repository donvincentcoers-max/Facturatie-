# Facturatie — Next.js app voor Vercel

Dit is de webversie van je facturatie-app. In tegenstelling tot de Claude-artifact
versie draait dit op een echte server met een database, login per teamlid, en
automatisch versturen van facturen per e-mail.

## Wat is er anders dan de artifact-versie?

- **Database in plaats van lokale opslag** — alle data (locaties, huurders,
  facturen, instellingen) staat in een Postgres-database, zodat niets verloren
  gaat en je hele team dezelfde gegevens ziet.
- **Login per teamlid** — niemand kan bij de app zonder account. Nieuwe
  teamleden maken een account aan met een teamcode die jij bepaalt.
- **Echt e-mail versturen** — facturen worden per e-mail verstuurd via
  [Resend](https://resend.com), met de PDF als bijlage. Dit vervangt het
  "e-mailconcept kopiëren"-scherm uit de artifact-versie.

## 1. Zet de code in een Git-repository

Upload deze map naar een nieuwe repository op GitHub (of GitLab/Bitbucket).
Vercel deployt rechtstreeks vanuit Git.

```bash
cd factuur-app
git init
git add .
git commit -m "Eerste versie facturatie-app"
# maak een lege repo aan op GitHub en:
git remote add origin <jouw-repo-url>
git push -u origin main
```

## 2. Maak een Vercel-project

1. Ga naar [vercel.com](https://vercel.com) → **Add New… → Project** → kies je repository.
2. Laat de standaardinstellingen staan (Next.js wordt automatisch herkend).
3. Klik **nog niet** op Deploy — voeg eerst de database en omgevingsvariabelen toe (stap 3 en 4).

## 3. Voeg een Postgres-database toe

1. Ga in je Vercel-project naar het tabblad **Storage → Create Database → Postgres**.
2. Koppel de database aan je project. Vercel zet automatisch de variabelen
   `POSTGRES_PRISMA_URL` en `POSTGRES_URL_NON_POOLING` klaar — daar hoef je zelf
   niets voor te doen.

## 4. Omgevingsvariabelen instellen

Ga naar **Settings → Environment Variables** en voeg toe (zie ook `.env.example`):

| Variabele | Uitleg |
|---|---|
| `NEXTAUTH_SECRET` | Willekeurige geheime waarde. Genereer lokaal met `openssl rand -base64 32`. |
| `NEXTAUTH_URL` | De uiteindelijke URL van je app, bijv. `https://factuur.vercel.app`. |
| `TEAM_SIGNUP_CODE` | Zelf te kiezen wachtwoord dat teamleden nodig hebben om een account te maken op `/register`. Deel dit **niet** publiekelijk. |
| `RESEND_API_KEY` | API-key uit je [Resend](https://resend.com)-account. |
| `RESEND_FROM_EMAIL` | Het afzenderadres, bijv. `facturatie@jouwdomein.nl`. Hiervoor moet je in Resend eerst je eigen domein verifiëren (DNS-records toevoegen) — anders kun je alleen naar jezelf testen. |

`POSTGRES_PRISMA_URL` en `POSTGRES_URL_NON_POOLING` staan er al dankzij stap 3.

## 5. Deploy

Klik op **Deploy**. Vercel installeert de dependencies, genereert het
databaseschema (`prisma db push`, ingebouwd in het build-script) en bouwt de
app. Bij een lege database worden de tabellen automatisch aangemaakt — je hoeft
zelf geen migraties te draaien.

## 6. Eerste accounts aanmaken

Ga naar `https://<jouw-app>.vercel.app/register`, vul je naam, e-mail en
wachtwoord in, en gebruik de `TEAM_SIGNUP_CODE` die je in stap 4 hebt ingesteld.
Doe dit voor elk teamlid dat toegang moet krijgen. Wil je registratie later
dichtzetten, verwijder of verander dan de `TEAM_SIGNUP_CODE`.

## Lokaal ontwikkelen

```bash
npm install
cp .env.example .env       # vul de echte waarden in
npx prisma db push          # zet het schema in je database
npm run dev
```

## Beveiliging — dingen om te weten

- Alle pagina's onder `/dashboard`, `/locations`, `/tenants`, `/invoices` en
  `/settings` zijn afgeschermd achter login (zie `middleware.ts`). Alleen
  `/login` en `/register` zijn zonder account bereikbaar.
- Iedereen met een account ziet dezelfde gedeelde data (net als de
  "gedeeld team-overzicht" uit de artifact-versie) — er is geen aparte
  rechtenstructuur per teamlid.
- IBAN's en persoonsgegevens van huurders staan in de database en worden nooit
  publiek getoond zonder in te loggen.
- `TEAM_SIGNUP_CODE` is de enige drempel tegen willekeurige accountaanmaak —
  bewaar deze net zo zorgvuldig als een wachtwoord.
